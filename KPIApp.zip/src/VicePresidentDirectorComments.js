import React from 'react'

export default function VicePresidentDirectorComments() {
  return (
    <div>VicePresidentDirectorComments</div>
  )
}
